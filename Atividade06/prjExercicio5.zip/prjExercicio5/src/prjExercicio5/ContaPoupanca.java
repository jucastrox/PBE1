package prjExercicio5;

public class ContaPoupanca extends contaBancaria {
	private double taxaJuros;
	
	//metodos da subclasse
	public void calcularJuros() {
		taxaJuros + saldo
	}
}
