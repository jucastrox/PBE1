package prjExercicio3;

public class animal {
	//atributos
		private String nome;
		private int idade;
		private String raca;
		
		//construtores
		public animal () {
		
		}
		public animal (String nome, int idade, String raca) {
			this.nome= nome;
			this.idade= idade;
			this.raca= raca;
		}
		
	//metodos
		public void fazerSom() {
			System.out.println("O animal fez um som");
		}
		
		
}
