package prjExercicio3;

public class leao extends animal {
		//metodo da subclasse
	public void cacar() {
		System.out.println(this.nome+" está caçando.");
	}
	
	//metodo da classe principal
	@Override
	public void fazerSom() {
		System.out.println("RUUARRR");
	}
}
