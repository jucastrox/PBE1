package prjExercicio3;

public class baleia extends animal {
	//metodos da subclasse
	public void nadar() {
		System.out.println(this.nome + " está nadando.");
	}
}
