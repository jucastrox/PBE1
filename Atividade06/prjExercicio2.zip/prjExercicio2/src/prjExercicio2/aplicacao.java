package prjExercicio2;

public class aplicacao {

	public static void main(String[] args) {
		livro DaisyJones = new livro();
		DaisyJones.setTitulo("Daisy Jones & the six");
		DaisyJones.setAutor("Taylor Jenkins Reid");
		DaisyJones.setNumeroPaginas(400);
		DaisyJones.setPreco(40);
        
		livro CarrieSoto = new livro();
		CarrieSoto.setTitulo("Carrie Soto está de volta");
		CarrieSoto.setAutor("Taylor Jenkins Reid");
		CarrieSoto.setNumeroPaginas(390);
		CarrieSoto.setPreco(35);
		
		livro EvelynHugo = new livro ();
		EvelynHugo.setTitulo("Os sete maridos de Evelyn Hugo");
		EvelynHugo.setAutor("Taylor Jenkins Reid");
		EvelynHugo.setNumeroPaginas(380);
		EvelynHugo.setPreco(38);
		
		DaisyJones.exibirInfo();
		DaisyJones.aplicarDesconto();
		CarrieSoto.exibirInfo();
		EvelynHugo.exibirInfo();
		EvelynHugo.aplicarDesconto();
		
		
	}

}
