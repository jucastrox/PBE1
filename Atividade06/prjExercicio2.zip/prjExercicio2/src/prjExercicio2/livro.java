package prjExercicio2;

public class livro {
	//atributos
	private String titulo;
	private String autor;
	private int numeroPaginas;
	private double preco;
	
	//construtores 
	public livro () {
		
	}
	public livro (String titulo, String autor, int numeroPaginas, double preco){
		this.autor = autor;
		this.titulo = titulo;
		this.numeroPaginas = numeroPaginas;
		this.preco = preco;
	}
	//getters and setters
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getNumeroPaginas() {
		return numeroPaginas;
	}
	public void setNumeroPaginas(int numeroPaginas) {
		this.numeroPaginas = numeroPaginas;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	//metodos
	public void aplicarDesconto() {
		System.out.println("Preço após desconto:");
		System.out.println(this.preco - 15);
    }
	public void exibirInfo() {
		System.out.println("Titulo: " + this.titulo);
		System.out.println("Autor: " + this.autor);
		System.out.println("Número de paginas: " + this.numeroPaginas);
		System.out.println("Preço: " + this.preco);
	}
	
}
