package prjExercicio4;

public class veiculo {
	//atributos
	private String marca;
	private String modelo;
	private int velocidade;
	
	//construtores
	public veiculo () {
		
	}
	public veiculo (String marca, String modelo, int velocidade) {
		this.marca = marca;
		this.modelo = modelo;
		this.velocidade = velocidade;
		
	//getters and setters
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public int getVelocidade() {
		return velocidade;
	}
	public void setVelocidade(int velocidade) {
		this.velocidade = velocidade;
	}

	public void acelerar() {
		System.out.println("Veiculo acelerando, sua velocidade agora é:");
		System.out.println(this.velocidade + 10);
	}
	public void frear() {
		System.out.println("Veiculo freando, sua velocidade agora é:");
		System.out.println(this.velocidade - 10);
	}
	
}

