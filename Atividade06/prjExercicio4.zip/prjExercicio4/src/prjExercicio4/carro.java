package prjExercicio4;

public class carro extends veiculo{
	@Override
	public void acelerar () {
		System.out.println("O Carro está acelerando");
	}
	@Override
	public void frear () {
		System.out.println("O carro está freiando");
	}
}
