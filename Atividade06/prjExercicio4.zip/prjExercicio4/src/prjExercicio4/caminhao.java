package prjExercicio4;

public class caminhao extends veiculo {
	@Override
	public void acelerar () {
		System.out.println("O Caminhão está acelerando");
	}
	@Override
	public void frear () {
		System.out.println("O caminhão está freiando");
	}
}
