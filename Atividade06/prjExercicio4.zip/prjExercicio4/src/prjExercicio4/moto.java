package prjExercicio4;

public class moto extends veiculo{
	@Override
	public void acelerar () {
		System.out.println("A moto está acelerando");
	}
	@Override
	public void frear () {
		System.out.println("A moto está acelerando");
	}
}
