package prjExercicio1;

public class carro {
	//atributos
	private String marca;
	private String modelo;
	private int velocidade;
	private String pecas;
	
	//construtores
	public carro () {
	
	}
	public carro (String marca, String modelo, int velocidade, String pecas) {
		this.modelo= modelo;
		this.marca= marca;
		this.pecas= pecas;
		this.velocidade= velocidade;
	}
	
	//getters and setters
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public int getVelocidade() {
		return velocidade;
	}
	public void setVelocidade(int velocidade) {
		this.velocidade = velocidade;
	}
	public String getPecas() {
		return pecas;
	}
	public void setPecas(String pecas) {
		this.pecas = pecas;
	}
	//metodos
		public void exibirInfo() {
			System.out.println("Marca: " + this.marca);
			System.out.println("Modelo: " + this.modelo);
			System.out.println("Velocidade: " + this.velocidade);
			System.out.println("Peças: " + this.pecas);
		}
}
