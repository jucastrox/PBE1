package prjExercicio1;

public class aplicacao {

	public static void main(String[] args) {
		
	carro CarroRosa= new carro();
	CarroRosa.setMarca("vrum vrum");
	CarroRosa.setModelo("Rosa");
	CarroRosa.setVelocidade(70);
	CarroRosa.setPecas("Rodas");
	
	
	carro CarroPreto = new carro();
	CarroPreto.setMarca("bibi");
	CarroPreto.setModelo("Preto");
	CarroPreto.setVelocidade(80);
	CarroPreto.setPecas("Banco");
	
	CarroPreto.exibirInfo();
	CarroRosa.exibirInfo();
	}

}
