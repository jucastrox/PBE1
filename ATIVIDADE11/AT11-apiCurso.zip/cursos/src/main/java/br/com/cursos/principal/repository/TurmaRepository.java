package br.com.cursos.principal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursos.principal.controller.TurmaController;
import br.com.cursos.principal.entities.Turma;

public interface TurmaRepository extends JpaRepository<TurmaController, Long> {

	Turma save(Turma turma);

}
