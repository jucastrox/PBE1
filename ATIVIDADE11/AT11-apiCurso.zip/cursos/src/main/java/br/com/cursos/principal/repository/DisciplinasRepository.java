package br.com.cursos.principal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursos.principal.controller.DisciplinasController;
import br.com.cursos.principal.entities.Disciplinas;

public interface  DisciplinasRepository extends JpaRepository<DisciplinasController, Long>{

	Disciplinas save(Disciplinas disciplinas);

}
