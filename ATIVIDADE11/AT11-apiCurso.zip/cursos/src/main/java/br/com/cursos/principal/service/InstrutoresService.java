package br.com.cursos.principal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.principal.controller.InstrutoresController;
import br.com.cursos.principal.entities.Instrutores;
import br.com.cursos.principal.repository.InstrutoresRepository;

@Service
public class InstrutoresService {
	@Autowired
    private InstrutoresRepository InstrutoresRepository;
    
    public Instrutores saveInstrutores(Instrutores Instrutores) {
        return InstrutoresRepository.save(Instrutores);
    }
    
    public List<InstrutoresController> getAllInstrutores(){
        return InstrutoresRepository.findAll();
    }
    public InstrutoresController getInstrutoresById (Long id_instrutores) {
        return InstrutoresRepository.findById(id_instrutores).orElse(null);
    }
    public void deleteInstrutores(Long id_Instrutores) {
    	InstrutoresRepository.deleteById(id_Instrutores);
    }
}
