package br.com.cursos.principal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursos.principal.controller.CursoController;
import br.com.cursos.principal.entities.Curso;

public interface CursoRepository extends JpaRepository<CursoController, Long>{

	Curso save(Curso curso);

}
