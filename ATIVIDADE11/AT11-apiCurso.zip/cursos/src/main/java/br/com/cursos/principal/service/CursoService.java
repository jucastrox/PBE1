package br.com.cursos.principal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.principal.controller.CursoController;
import br.com.cursos.principal.entities.Curso;
import br.com.cursos.principal.repository.CursoRepository;


@Service
public class CursoService {
	@Autowired
    private CursoRepository CursoRepository;
    
    public Curso saveCurso(Curso Curso) {
        return CursoRepository.save(Curso);
    }
    
    public List<CursoController> getAllCursos(){
        return CursoRepository.findAll();
    }
    public CursoController getCursoById (Long id_curso) {
        return CursoRepository.findById(id_curso).orElse(null);
    }
    public void deleteCurso(Long id_curso) {
        CursoRepository.deleteById(id_curso);
    }
}
