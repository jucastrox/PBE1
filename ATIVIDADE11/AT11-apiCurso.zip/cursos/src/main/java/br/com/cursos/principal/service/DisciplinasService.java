package br.com.cursos.principal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.principal.controller.DisciplinasController;
import br.com.cursos.principal.entities.Disciplinas;
import br.com.cursos.principal.repository.DisciplinasRepository;

@Service
public class DisciplinasService {
	@Autowired
    private DisciplinasRepository DisciplinasRepository;
    
    public Disciplinas saveDisciplinas(Disciplinas Disciplinas) {
        return DisciplinasRepository.save(Disciplinas);
    }
    
    public List<DisciplinasController> getAllDisciplinas(){
        return DisciplinasRepository.findAll();
    }
    public DisciplinasController getTurmaById (Long id_disciplinas) {
        return DisciplinasRepository.findById(id_disciplinas).orElse(null);
    }
    public void deleteDisciplinas(Long id_disciplinas) {
    	DisciplinasRepository.deleteById(id_disciplinas);
    }
}
