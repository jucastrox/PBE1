package br.com.cursos.principal.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_curso")
public class Curso {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_curso;
    
    @Column(name = "titulo")
    private String titulo;
    
    @Column(name = "descricao")
    private String descricao;
    
    @Column(name = "nivel_dificuldade")
    private int nivel_dificuldade;
    
    @Column(name = "carga_horaria")
    private int carga_horaria;
    
    //construtores
    public Curso() {
        
    }
    public Curso (Long id_curso, String titulo, String descricao, int nivel_dificuldade, int carga_horaria) {
        this.id_curso = id_curso;
        this.titulo = titulo;
        this.descricao = descricao;
        this.nivel_dificuldade = nivel_dificuldade;
        this.carga_horaria = carga_horaria;
    }
    
    //getters e setters
	public Long getId_curso() {
		return id_curso;
	}
	public void setId_curso(Long id_curso) {
		this.id_curso = id_curso;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public int getNivel_dificuldade() {
		return nivel_dificuldade;
	}
	public void setNivel_dificuldade(int nivel_dificuldade) {
		this.nivel_dificuldade = nivel_dificuldade;
	}
	public int getCarga_horaria() {
		return carga_horaria;
	}
	public void setCarga_horaria(int carga_horaria) {
		this.carga_horaria = carga_horaria;
	}
}