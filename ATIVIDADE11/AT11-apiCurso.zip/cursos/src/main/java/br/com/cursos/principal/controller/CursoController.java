package br.com.cursos.principal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursos.principal.entities.Curso;
import br.com.cursos.principal.service.CursoService;

@RestController
@RequestMapping("/Curso")
public class CursoController {
	@Autowired
    private CursoService CursoService;
    
    @PostMapping
    public Curso createLivro(Curso Curso) {
        return CursoService.saveCurso(Curso);
    }
    
    @GetMapping
    public List<CursoController> getAllCurso(){
        return CursoService.getAllCursos();
    }
    @GetMapping ("/{id_Curso}")
    public CursoController getCurso(@PathVariable Long id_curso) {
        return CursoService.getCursoById(id_curso);
    }
    @DeleteMapping("/{id_Curso}")
    public void deleteCurso(@PathVariable Long id_curso) {
        CursoService.deleteCurso(id_curso);
    }
}
