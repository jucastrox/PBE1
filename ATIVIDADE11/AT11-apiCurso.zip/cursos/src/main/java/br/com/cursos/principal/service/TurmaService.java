package br.com.cursos.principal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.principal.controller.TurmaController;
import br.com.cursos.principal.entities.Turma;
import br.com.cursos.principal.repository.TurmaRepository;

@Service
public class TurmaService {
	@Autowired
    private TurmaRepository TurmaRepository;
    
    public Turma saveTurma(Turma Turma) {
        return TurmaRepository.save(Turma);
    }
    
    public List<TurmaController> getAllTurma(){
        return TurmaRepository.findAll();
    }
    public TurmaController getTurmaById (Long id_turma) {
        return TurmaRepository.findById(id_turma).orElse(null);
    }
    public void deleteTurma(Long id_turma) {
        TurmaRepository.deleteById(id_turma);
    }

}
