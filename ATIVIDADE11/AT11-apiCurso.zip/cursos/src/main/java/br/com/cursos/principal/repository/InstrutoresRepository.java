package br.com.cursos.principal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursos.principal.controller.InstrutoresController;
import br.com.cursos.principal.entities.Instrutores;

public interface InstrutoresRepository extends JpaRepository<IntrutoresController, Long>{
	Instrutores save(Instrutores instrutores);
}

