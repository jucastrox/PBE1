package br.com.cursos.principal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursos.principal.controller.AlunosController;
import br.com.cursos.principal.entities.Alunos;
import br.com.cursos.principal.repository.AlunosRepository;

@Service

public class AlunosService {
	@Autowired
    private AlunosRepository AlunosRepository;
    
    public Alunos saveAlunos(Alunos Alunos) {
        return AlunosRepository.save(Alunos);
    }
    
    public List<AlunosController> getAllAlunos(){
        return AlunosRepository.findAll();
    }
    public AlunosController getAlunosById (Long id_alunos) {
        return AlunosRepository.findById(id_alunos).orElse(null);
    }
    public void deleteAlunos(Long id_alunos) {
        AlunosRepository.deleteById(id_alunos);
    }
}
