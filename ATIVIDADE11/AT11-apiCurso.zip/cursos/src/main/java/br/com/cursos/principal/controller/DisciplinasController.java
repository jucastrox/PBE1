package br.com.cursos.principal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursos.principal.entities.Disciplinas;
import br.com.cursos.principal.service.DisciplinasService;

@RestController
@RequestMapping("/Disciplinas")
public class DisciplinasController {
	@Autowired
    private DisciplinasService DisciplinasService;
    
    @PostMapping
    public Disciplinas createDisciplinas(Disciplinas Disciplinas) {
        return DisciplinasService.saveDisciplinas(Disciplinas);
    }
    
    @GetMapping
    public List<DisciplinasController> getAllDisciplinas(){
        return DisciplinasService.getAllDisciplinas();
    }
    @GetMapping ("/{id_disciplinas}")
    public DisciplinasController getDisciplinas(@PathVariable Long id_disciplinas) {
        return DisciplinasService.getDisciplinasById(id_disciplinas);
    }
    @DeleteMapping("/{id_disciplinas}")
    public void deleteDisciplinas (@PathVariable Long id_disciplinas) {
    	DisciplinasService.deleteDisciplinas(id_disciplinas);
    }
}
