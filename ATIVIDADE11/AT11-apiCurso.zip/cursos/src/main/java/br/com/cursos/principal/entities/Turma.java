package br.com.cursos.principal.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_turma")
public class Turma {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_turma;
    
    @Column(name = "data_inicio")
    private int data_inicio;
    
    @Column(name = "data_termino")
    private int data_termino;
    
    @Column(name = "horario")
    private int horario;
    
    @Column(name = "vagas")
    private int vagas;
    
  //construtores
    public Turma() {
        
    }
    public Turma(Long id_turma, int data_inicio, int data_termino, int horario, int vagas) {
        this.id_turma = id_turma;
        this.data_inicio = data_inicio;
        this.data_termino = data_termino;
        this.horario = horario;
        this.vagas = vagas;
    }
    
    //getters e setters
	public Long getId_turma() {
		return id_turma;
	}
	public void setId_turma(Long id_turma) {
		this.id_turma = id_turma;
	}
	public int getData_inicio() {
		return data_inicio;
	}
	public void setData_inicio(int data_inicio) {
		this.data_inicio = data_inicio;
	}
	public int getData_termino() {
		return data_termino;
	}
	public void setData_termino(int data_termino) {
		this.data_termino = data_termino;
	}
	public int getHorario() {
		return horario;
	}
	public void setHorario(int horario) {
		this.horario = horario;
	}
	public int getVagas() {
		return vagas;
	}
	public void setVagas(int vagas) {
		this.vagas = vagas;
	}
    
}
