package br.com.cursos.principal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursos.principal.controller.AlunosController;
import br.com.cursos.principal.entities.Alunos;

public interface AlunosRepository extends JpaRepository<AlunosController, Long>{

	Alunos save(Alunos alunos);
}
