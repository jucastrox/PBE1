package br.com.cadastro.principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroLivroApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroLivroApplication.class, args);
	}

}
