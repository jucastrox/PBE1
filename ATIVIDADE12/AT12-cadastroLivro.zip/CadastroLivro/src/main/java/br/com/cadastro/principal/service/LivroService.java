package br.com.cadastro.principal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cadastro.principal.controller.LivroController;
import br.com.cadastro.principal.entities.Livro;
import br.com.cadastro.principal.repository.LivroRepository;

@Service
public class LivroService {
	@Autowired
    private LivroRepository LivroRepository;
    
    public Livro saveLivro(Livro Livro) {
        return LivroRepository.save(Livro);
    }
    
    public List<LivroController> getAllLivro(){
        return LivroRepository.findAll();
    }
    public LivroController getLivroById (Long id_livro) {
        return LivroRepository.findById(id_livro).orElse(null);
    }
    public void deleteLivro(Long id_livro) {
        LivroRepository.deleteById(id_livro);
    }

}
