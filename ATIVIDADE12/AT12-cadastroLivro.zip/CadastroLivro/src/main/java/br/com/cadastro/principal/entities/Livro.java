package br.com.cadastro.principal.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_livros")
public class Livro {
	//atributos
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_livro")
	private long id_livro;
	@Column(name = "descricao")
	private String descricao;
	@Column(name = "isbn")
	private String isbn;
	
	//construtores
	
public Livro () {
		
	}
	public Livro (long id_livro, String descricao, String isbn) {
		this.id_livro = id_livro;
		this.descricao = descricao;
		this.isbn = isbn;
	}
	
	//getters e setters
	public long getId_livro() {
		return id_livro;
	}
	public void setId_livro(long id_livro) {
		this.id_livro = id_livro;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	
	
}
