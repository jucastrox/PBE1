package br.com.cadastro.principal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cadastro.principal.controller.LivroController;
import br.com.cadastro.principal.entities.Livro;

public interface LivroRepository extends JpaRepository<LivroController, Long>{

	Livro save(Livro livro);

}
