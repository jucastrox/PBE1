package prjZoologico;

public class SubClasseCarnivoros extends ClasseAnimal {
	//metodo da subclasse
	public void metodoCacar() {
		System.out.println(this.atributoNome + " está caçando.");
	}
}
