/**
 * 
 */
/**
 * 
 */
module prjPokémon {
}