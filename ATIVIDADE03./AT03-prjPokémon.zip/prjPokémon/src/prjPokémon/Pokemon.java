package prjPokémon;

public class Pokemon {
	//Atributos
		String nome;
		String tipo;
		double nivel;
		double hp;
		
		//Construtores
		
		public Pokemon () {
			
		}
		public Pokemon(String parametroNome, String parametroTipo, double parametroNivel, double parametroHp) {
			this.nome = parametroNome;
			this.tipo = parametroTipo;
			this.nivel = parametroNivel;
			this.hp = parametroHp;
		}
	
		//metodos
		public void metodoAtacar() {
			System.out.println(this.nome + " atacou");
			}
		public void metodoEvoluir() {
			System.out.println(this.nome + " evloluiu");
		}
		public void exibirInfo() {
			System.out.println("Nome: " + this.nome);
			System.out.println("Nivel: " + this.nivel);
			}
}
