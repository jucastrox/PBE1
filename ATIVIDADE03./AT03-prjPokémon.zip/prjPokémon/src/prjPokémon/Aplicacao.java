package prjPokémon;

public class Aplicacao {

	public static void main(String[] args) {
	Pokemon Pikachu = new Pokemon();
	Pikachu.nome = "Pikachu";
	Pikachu.tipo = "eletric";
	Pikachu.nivel = 10;
	Pikachu.hp = 65;
	
	Pokemon nidorino = new Pokemon();
	nidorino.nome = "Nidorino";
	nidorino.tipo = "poison";
	nidorino.nivel = 11;
	nidorino.hp = 65;
	
	Pokemon clefairy = new Pokemon();
	clefairy.nome = "clefairy";
	clefairy.tipo = "fairy";
	clefairy.nivel = 14;
	clefairy.hp = 65;
	
	Pokemon raichu = new Pokemon();
	raichu.nome = "raichu";
	raichu.tipo = "eletric";
	raichu.nivel = 13;
	raichu.hp = 65;
	
	Pokemon goldbat = new Pokemon();
	goldbat.nome = "raichu";
	goldbat.tipo = "flying";
	goldbat.nivel = 12;
	goldbat.hp = 65;
	
	Pikachu.exibirInfo();
	Pikachu.metodoAtacar();
	Pikachu.metodoEvoluir();
	
	nidorino.exibirInfo();
	nidorino.metodoAtacar();
	nidorino.metodoEvoluir();
	
	clefairy.exibirInfo();
	clefairy.metodoAtacar();
	clefairy.metodoEvoluir();
	
	raichu.exibirInfo();
	raichu.metodoAtacar();
	raichu.metodoEvoluir();
	
	goldbat.exibirInfo();
	goldbat.metodoAtacar();
	goldbat.metodoEvoluir();
	
	}

}
