package prjZoo;

public class SubClasseCarnivoros extends ClasseAnimal{
	//metodo da subclasse
		public void metodoCacar() {
			System.out.println(this.atributoNome + " está caçando.");
		}
		
		@Override
		public void metodoEmitirSom () {
			System.out.println("RUUARRR");
}
