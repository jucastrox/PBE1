package br.com.bibiotecasenai.itens;

import br.com.bibiotecasenai.usuarios.Usuario;

public class Emprestimo{
	//atributos
	private int numeroEmprestimo;
	
	//metodos
	public void emprestarLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()+1);
	}
	public void devolverLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()-1);
	}
	
	public void exibirInfo(Livro livro, Usuario usuario) {
	usuario.setLivrosEmprestados(usuario.getLivrosEmprestados());
	usuario.setLivrosEmprestados(usuario.getLivrosEmprestados());
	}
}
