package br.com.bibiotecasenai.itens;

public class Livro {
	//atributos
	private String titulo;
	private String autor;
	private int isbn;
	private double disponivel;
	
	public Livro() {
		
	}
	public Livro(String titulo, String autor, int isbn, double disponivel) {
		this.autor= autor;
		this.titulo= titulo;
		this.isbn= isbn;
		this.disponivel= disponivel;
	}
	
	//getters and setters
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public double getDisponivel() {
		return disponivel;
	}
	public void setDisponivel(double disponivel) {
		this.disponivel = disponivel;
	}
	
	
}
