package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.*;
import br.com.bibiotecasenai.itens.*;

public class Aplicacao {

	public static void main(String[] args) {
		
	Usuario usuario01 = new Usuario();
	usuario01.setNome("Rafaela");
	usuario01.setCpf(123456789);
	usuario01.setIdade(16);
	
	Usuario usuario02 = new Usuario();
	usuario02.setNome("Murilo");
	usuario02.setCpf(987654321);
	usuario02.setIdade(17);
	
	Bibliotecario bibliotecario = new Bibliotecario();
	bibliotecario.setNome("Leandro");
	bibliotecario.setIdade(45);
	
	for(int i = 0; i < 10; i++) {
	 emprestarLivro();
	}
	for(int i = 0; i < 8; i--) {
	devolverLivro();
	}
	exibirInfo();
	}

}
