package br.com.bibiotecasenai.usuarios;

public class Pessoa {
	//atributos
	private String nome;
	private int idade;
	
	//construtores
	public Pessoa() {
		
	}
	public Pessoa(String nome, int idade) {
		this.idade= idade;
		this.nome= nome;
	}
	
	//getters and setters 
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
}
