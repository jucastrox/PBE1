package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa {
	//atributos
	private String matricula;
	
	//metodos
		public void realizarEmprestimo() {
		System.out.println(this.getNome() + " realizou um emprestimo");
		}
		
		public void devolverLivro() {
		System.out.println(this.getNome()+" devolveu livro");
		}
}
